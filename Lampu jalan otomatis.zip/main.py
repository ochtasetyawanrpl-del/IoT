#define LDR_PIN 36 // Pin ADC1_CH0
#define LAMP_PIN 5
#define THRESHOLD 2000 // Ambang batas nilai ADC
void setup() {
Serial.begin(115200);
pinMode(LAMP_PIN, OUTPUT);
Serial.println("Sistem Otomatisasi Lampu Jalan Ready.");
}
void loop() {
int ldrValue = analogRead(LDR_PIN);
Serial.print("Nilai Cahaya Analog (ADC): ");
Serial.println(ldrValue);
// Pada ESP32 & Wokwi: Makin Gelap = Nilai ADC makin tinggi / sebaliknya tergantung
rangkaian
if (ldrValue > THRESHOLD) {
digitalWrite(LAMP_PIN, HIGH);
Serial.println("Status: GELAP -> Lampu Menyala [ON]");
} else {
digitalWrite(LAMP_PIN, LOW);
Serial.println("Status: TERANG -> Lampu Mati [OFF]");
}
delay(1000);
}