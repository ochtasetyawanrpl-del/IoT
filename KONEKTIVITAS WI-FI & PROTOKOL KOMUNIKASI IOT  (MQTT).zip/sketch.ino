#include <WiFi.h>
#include <PubSubClient.h>
#include <DHT.h>
// Konfigurasi Pin & Sensor
#define DHTPIN 15
#define DHTTYPE DHT22
#define LED_PIN 2
DHT dht(DHTPIN, DHTTYPE);
// Konfigurasi Wi-Fi Wokwi
const char* ssid = "Wokwi-GUEST";
const char* password = "";
// Konfigurasi Public MQTT Broker
const char* mqtt_server = "broker.hivemq.com";
const int mqtt_port = 1883;
// Topik MQTT (Ganti 'peserta01' dengan nama/NIM Anda)
const char* topic_suhu = "iot/pelatihan/pramudya/suhu";

const char* topic_lembap = "iot/pelatihan/pramudya/kelembapan";
const char* topic_lampu = "iot/pelatihan/pramudya/lampu";
WiFiClient espClient;
PubSubClient client(espClient);
unsigned long lastMsg = 0;
void setup_wifi() {
delay(10);
Serial.print("Menghubungkan ke Wi-Fi: ");
Serial.println(ssid);
WiFi.mode(WIFI_STA);
WiFi.begin(ssid, password);
while (WiFi.status() != WL_CONNECTED) {
delay(500);
Serial.print(".");
}
Serial.println();
Serial.println("Wi-Fi Terhubung!");
Serial.print("IP Address: ");
Serial.println(WiFi.localIP());
}
// Fungsi Callback saat menerima pesan dari topik yang di-Subscribe
void callback(char* topic, byte* payload, unsigned int length) {
String pesan = "";
for (unsigned int i = 0; i < length; i++) {
pesan += (char)payload[i];
}
Serial.print("Pesan masuk [");
Serial.print(topic);
Serial.print("]: ");
Serial.println(pesan);
// Kontrol LED berdasarkan pesan
if (String(topic) == topic_lampu) {
if (pesan == "ON" || pesan == "1") {
digitalWrite(LED_PIN, HIGH);
Serial.println("Status LED: MENYALA");
} else if (pesan == "OFF" || pesan == "0") {
digitalWrite(LED_PIN, LOW);

Serial.println("Status LED: MATI");
}
}
}
void reconnect() {
while (!client.connected()) {
Serial.print("Menghubungkan ke MQTT Broker...");
String clientId = "ESP32Client-";
clientId += String(random(0xffff), HEX);
if (client.connect(clientId.c_str())) {
Serial.println("Terhubung!");
client.subscribe(topic_lampu);
Serial.print("Subscribed ke topik: ");
Serial.println(topic_lampu);
} else {
Serial.print("Gagal, rc=");
Serial.print(client.state());
Serial.println(" coba lagi dalam 5 detik");
delay(5000);
}
}
}
void setup() {
pinMode(LED_PIN, OUTPUT);
Serial.begin(115200);
dht.begin();
setup_wifi();
client.setServer(mqtt_server, mqtt_port);
client.setCallback(callback);
}
void loop() {
if (!client.connected()) {
reconnect();
}
client.loop();
unsigned long now = millis();
if (now - lastMsg > 3000) {
lastMsg = now;

float kelembapan = dht.readHumidity();
float suhu = dht.readTemperature();
if (isnan(kelembapan) || isnan(suhu)) {
Serial.println("Gagal membaca sensor DHT22!");
return;
}
char strSuhu[8];
char strLembap[8];
dtostrf(suhu, 1, 2, strSuhu);
dtostrf(kelembapan, 1, 2, strLembap);
client.publish(topic_suhu, strSuhu);
client.publish(topic_lembap, strLembap);
Serial.print("Publish Suhu: ");
Serial.print(strSuhu);
Serial.print(" °C | Kelembapan: ");
Serial.print(strLembap);
Serial.println(" %");

}
}