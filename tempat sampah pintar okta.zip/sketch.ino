// SMART TRASH CAN + VOLUME
// IoT #8 Grade 9 2026

#define BLYNK_TEMPLATE_ID "TMPL6XvIRVUPf"
#define BLYNK_TEMPLATE_NAME "Smart Trash Can Volume Sinchan"
#define BLYNK_AUTH_TOKEN "YUni8bUK5EJZeJLb655kqnmcDgVfXsR3"

#include <WiFi.h>
#include <BlynkSimpleEsp32.h>
#include <ESP32Servo.h>

char auth[] = BLYNK_AUTH_TOKEN;
char ssid[] = "Wokwi-GUEST";
char pass[] = "";

// Konfigurasi Pin
const int trigLuar = 5;
const int echoLuar = 18;
const int trigDalam = 14;
const int echoDalam = 12;
const int servoPin = 13;

// Variabel Fisik Kotak
const float tinggiMaksimal = 50.0; // Tinggi kotak dalam cm

Servo myServo;
BlynkTimer timer;

// Fungsi Helper untuk baca jarak agar kode lebih rapi
float bacaJarak(int trig, int echo) {
  digitalWrite(trig, LOW);
  delayMicroseconds(2);
  digitalWrite(trig, HIGH);
  delayMicroseconds(10);
  digitalWrite(trig, LOW);
  long durasi = pulseIn(echo, HIGH);
  return durasi * 0.034 / 2;
}

void sistemTempatSampah() {
  // 1. Logika Sensor Luar (Buka Tutup)
  float jarakLuar = bacaJarak(trigLuar, echoLuar);
  
  if (jarakLuar > 0 && jarakLuar < 15) {
    myServo.write(90); // Buka
    Blynk.virtualWrite(V1, "TERBUKA");
  } else {
    myServo.write(0);  // Tutup
    Blynk.virtualWrite(V1, "TERTUTUP");
  }

  // 2. Logika Sensor Dalam (Volume)
  // Tips: Volume hanya akurat dibaca saat tutup sedang posisi normal (Tutup)
  float jarakDalam = bacaJarak(trigDalam, echoDalam);
  
  float tinggiSampah = tinggiMaksimal - jarakDalam;
  if (tinggiSampah < 0) tinggiSampah = 0;
  
  int persen = (tinggiSampah / tinggiMaksimal) * 100;
  if (persen > 100) persen = 100;

  // Tentukan Status
  String statusIsi;
  if (persen >= 90) statusIsi = "PENUH!";
  else if (persen >= 50) statusIsi = "SETENGAH";
  else statusIsi = "KOSONG";

  // 3. Kirim ke Blynk
  Blynk.virtualWrite(V7, persen);    // Gauge Persentase
  Blynk.virtualWrite(V8, statusIsi); // Teks Status
  
  Serial.print("Luar: "); Serial.print(jarakLuar);
  Serial.print("cm | Dalam: "); Serial.print(persen); Serial.println("%");
}

void setup() {
  Serial.begin(115200);
  
  myServo.attach(servoPin);
  myServo.write(0);
  
  pinMode(trigLuar, OUTPUT);
  pinMode(echoLuar, INPUT);
  pinMode(trigDalam, OUTPUT);
  pinMode(echoDalam, INPUT);

  Blynk.begin(auth, ssid, pass);
  timer.setInterval(1000L, sistemTempatSampah);
}

void loop() {
  Blynk.run();
  timer.run();
}